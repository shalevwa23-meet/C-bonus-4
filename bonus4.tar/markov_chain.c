#include "markov_chain.h"


Node *get_node_from_database(MarkovChain *markov_chain, void *data_ptr)
{
  comp_function comp_func = markov_chain->comp_func;
  LinkedList *db = markov_chain -> database;
  Node *cur_node = db -> first;
  while (cur_node != NULL)
  {
    MarkovNode *cur_markov_node = cur_node -> data;
    void *cur_str = cur_markov_node -> data;
    if (comp_func(cur_str, data_ptr) == 0)
    {
      return cur_node;
    }
    cur_node = cur_node -> next;
  }
  return NULL;
}

Node *add_to_database(MarkovChain *markov_chain, void *data_ptr)
{
  copy_function copy_func = markov_chain->copy_func;
  Node *existing = get_node_from_database(markov_chain, data_ptr);
  if (existing)
  {
    return existing;
  }
  Node *new_node = malloc(sizeof(Node));
  if (!new_node)
  {
    return NULL;
  }
  MarkovNode *new_markov_node = malloc(sizeof(MarkovNode));
  if (!new_markov_node)
  {
    free(new_node);
    return NULL;
  }
  void* new_data = copy_func(data_ptr);
  if(new_data == NULL)
  {
    free(new_node);
    free(new_markov_node);
    return NULL;
  }
  new_markov_node -> data = new_data;
  new_markov_node -> frequency_list = NULL;

  new_markov_node -> size_of_frequency_list = 0;
  new_node -> data = new_markov_node;

  new_node -> next = NULL;

  LinkedList *db = markov_chain -> database;

  if(db -> first == NULL)
  {
    db -> first = new_node;
    db -> last = new_node;
  }
  else
  {
    db -> last -> next = new_node;
  }

  db -> last = new_node;
  return new_node;
}

int add_node_to_frequency_list(MarkovNode *first_node,
                               MarkovNode *second_node)
{
  MarkovNodeFrequency *freq_list = first_node -> frequency_list;
  size_t size = first_node -> size_of_frequency_list;
  for(size_t i = 0; i < size; i++)
  {
    MarkovNode* existing_node = (freq_list+i) -> markov_node;
    if (existing_node == second_node)
    {
      (freq_list+i) -> frequency++;
      return SUCCESS;
    }
  }
  size_t new_size = (size+1)*sizeof(MarkovNodeFrequency);
  MarkovNodeFrequency *new_freq_list = realloc(freq_list, new_size);
  if (!new_freq_list)
  {
    return FAILURE;
  }
  (new_freq_list+size) -> markov_node = second_node;
  (new_freq_list+size) -> frequency = 1;
  first_node -> frequency_list = new_freq_list;
  first_node -> size_of_frequency_list++;
  return SUCCESS;
}


void free_database(MarkovChain **chain_ptr)
{
  MarkovChain *chain = *chain_ptr;
  free_function free_func = chain->free_data;
  LinkedList *db = chain -> database;
  Node *node = db -> first;
  while (node != NULL)
  {
    MarkovNode* markov_node = node -> data;
    void* data = markov_node -> data;
    MarkovNodeFrequency* frequency_list = markov_node -> frequency_list;
    free_func(data);
    free(frequency_list);
    free(markov_node);
    Node* next_node = node -> next;
    free(node);
    node = next_node;
  }
  free(db);
  free(chain);
}

/**
 * Calculate the number of nodes in the Markov chain's database.
 * @param markov_chain Pointer to the Markov chain.
 * @return The number of nodes in the database.
 */
size_t get_chain_length(MarkovChain *markov_chain)
{
  LinkedList *db = markov_chain -> database;
  Node *cur_node = db -> first;
  size_t size = 0;
  while (cur_node != NULL)
  {
    size++;
    cur_node = cur_node -> next;
  }
  return size;
}


MarkovNode *get_first_random_node(MarkovChain *markov_chain)
{
  is_last_function is_last = markov_chain->is_last;
  size_t size = get_chain_length(markov_chain);
  Node* cur_node = markov_chain -> database -> first;
  while(true)
  {
    cur_node = markov_chain -> database -> first;
    int index = get_random_number(size);
    for(int i = 0; i < index; i++)
    {
      cur_node = cur_node -> next;
    }

    if(!is_last(cur_node -> data -> data))
    {
      break;
    }
  }
  return cur_node -> data;
}


/**
 * Get the index of a Markov node based on its occurrence frequency.
 * @param freq_list Pointer to the frequency list array.
 * @param index Random index within the cumulative frequency count.
 * @return The index of the chosen Markov node in the frequency list.
 */
int get_index_with_freq(MarkovNodeFrequency *freq_list, int index)
{
  int temp = 0;
  int j = 0;
  int i = 0;
  while(true)
  {
    temp = (freq_list+i) -> frequency;
    while(temp > 0)
    {
      j++;
      if(j >= index+1)
      {
        return i;
      }
      temp--;
    }
    i++;
  }
}

MarkovNode *get_next_random_node(MarkovNode *cur_markov_node)
{
  MarkovNodeFrequency *freq_list = cur_markov_node -> frequency_list;
  size_t size = cur_markov_node -> size_of_frequency_list;
  size_t total = 0;

  for(size_t i = 0; i < size; i++)
  {
    total += (freq_list+i) -> frequency;
  }
  int index = get_random_number(total);

  int i = get_index_with_freq(freq_list, index);
  
  MarkovNode *chosen = (freq_list+i) -> markov_node;
  return chosen;
}


void generate_random_sequence(MarkovChain *markov_chain,
                              MarkovNode *first_node, int max_length)
{
  print_function print_func = markov_chain->print_func;
  is_last_function is_last = markov_chain->is_last;
  MarkovNode *cur_node = first_node;
  print_func(cur_node->data);
  for(int i = 0; i < max_length-1; i++)
  {
    cur_node = get_next_random_node(cur_node);
    void* data = cur_node -> data;
    print_func(data);
    if(is_last(data))
    {
      return;
    }
  }
}

/**
 * Get random number between 0 and max_number [0, max_number).
 * @param max_number
 * @return Random number
 */
int get_random_number(int max_number)
{
    return rand() % max_number;
}